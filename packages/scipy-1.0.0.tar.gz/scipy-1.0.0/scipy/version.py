
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '1.0.0'
version = '1.0.0'
full_version = '1.0.0'
git_revision = '11509c4a98edded6c59423ac44ca1b7f28fba1fd'
release = True

if not release:
    version = full_version
